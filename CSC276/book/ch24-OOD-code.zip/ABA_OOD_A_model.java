//ABA_OOD_A_model.java: very simple object-oriented design example.
//   This class implements the model component.

import java.util.Collection;
import java.util.TreeMap;

public class ABA_OOD_A_model
{
	private ABA_OOD_A_modelXML modelXML;

	public ABA_OOD_A_model()
	{
		modelXML = new ABA_OOD_A_modelXML();
	}

	//pre:  A name and phone needs to be added to the address book.
	//post: A name and phone were added to the address book ONLY IF
	//		  the name was not already in the book.
	public boolean addContact(ABA_OOD_contactData data)
	{
		boolean added = modelXML.addContact(data);
		return added;
	}
	
	//purpose: Exit the simulator.
	//assumptions: None.
	//inputs: None.
	//post-conditions: None.
	public void exitABA()
	{
		modelXML.saveDOMtoXML();
	}

	//pre:  A name may already be in the address book.
	//post: Returns data associated with the request's contact name.
	//		 Returns null when request's contact name not in address book.
	public ABA_OOD_contactData getContact(ABA_OOD_contactData requestData)
	{
		ABA_OOD_contactData data = modelXML.getContact(requestData);
		return data;
	}

	//pre:  Address book data structure exists.
	//post: Returns set of all contact names in the address book.
	public Collection<ABA_OOD_modelContact> getContactList()
	{
		return modelXML.getContactList();
	}
}
