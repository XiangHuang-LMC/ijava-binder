//ABA_OOD_modelContact.java: very simple object-oriented design example.
//   Meets same requirements as Chapter 10 except the design uses MVC. 
//   This class implements a container for contact data.

import java.util.Comparator;

//public class ABA_OOD_modelContact implements Comparator
public class ABA_OOD_modelContact
{
	private String id;
	private String name;
	private final String SEMICOLON = ";";

	public ABA_OOD_modelContact(String id, String name)
	{
		this.id = id;
		this.name = name;
	}
/*
	public int compare(ABA_OOD_modelContact one, ABA_OOD_modelContact two)
	{
		return one.getName().
	} */

	public String getId()
	{
		return id;
	}

	public String getName()
	{
		return name;
	}

	public String toString()
	{
		return name + SEMICOLON + id;
	}
}
