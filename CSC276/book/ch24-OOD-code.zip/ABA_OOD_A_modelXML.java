//ABA_OOD_A_modelXML.java: very simple object-oriented design example.
//   This class implements the model component.

import java.io.*;
import java.math.BigInteger;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;
import org.xml.sax.*;

public class ABA_OOD_A_modelXML
{
	private Document dom;
	private Element rootElement;
	private BigInteger maxId;
	private final String XML_FILE_NAME = "ABA_A.xml";
	private final String EMPTY_STRING = "";
	private final String NEWLINE = "\n";
	private final String TAGNAME_CONTACT = "contact";
	private final String TAGNAME_EMAILADDRESS = "emailAddress";
	private final String TAGNAME_ID = "id";
	private final String TAGNAME_NAME = "name";
	private final String TAGNAME_PHONENUMBER = "phoneNumber";

	public ABA_OOD_A_modelXML()
	{
		dom = createDOM(XML_FILE_NAME);
		//get the root Element from the DOM.
		rootElement = dom.getDocumentElement();
		//get the largest value for <id> currently in the DOM
		saveMaxIdValue();
	}

	//pre:  A name and phone needs to be added to the address book.
	//post: A name and phone were added to the address book ONLY IF
	//		  the name was not already in the book.
	public boolean addContact(ABA_OOD_contactData data)
	{
		boolean added = true;

		//create <contact> Element; make a child of the root element.
		Element contactElement = dom.createElement(TAGNAME_CONTACT);
		addChildElement(rootElement, contactElement);
		//create <id> Element and associated Text node; make child of contactElement
		maxId = maxId.add(BigInteger.ONE);
		addChildAndDataNodes(contactElement, TAGNAME_ID, maxId.toString());
		//create <name> Element and associated Text node; make child of contactElement
		extractAndSaveDataValues(contactElement, TAGNAME_NAME, data.getName());
//		addChildAndDataNodes(contactElement, TAGNAME_NAME, data.getName());
		//create <phoneNumber> Element and associated Text node; make child of contactElement
		extractAndSaveDataValues(contactElement, TAGNAME_PHONENUMBER, data.getPhone());
//		addChildAndDataNodes(contactElement, TAGNAME_PHONENUMBER, data.getPhone());
		//create <emailAddress> Element and associated Text node; make child of contactElement
		addChildAndDataNodes(contactElement, TAGNAME_EMAILADDRESS, data.getEmail());

		return added;
	}

	public ABA_OOD_contactData getContact(ABA_OOD_contactData requestData)
	{
		String id = requestData.getId();
		String name = requestData.getName();
		Node contactNode = getContactNode(id);
		String phone = EMPTY_STRING;
		String email = EMPTY_STRING;

		Node childNode = contactNode.getFirstChild();
		while (childNode != null)
		{
			if (childNode.getNodeType() == Node.ELEMENT_NODE)
			{
				String nodeName = childNode.getNodeName();
				if (nodeName.equals(TAGNAME_PHONENUMBER))
				{
					String phoneValue = getElementValue(childNode);
					if (phone.length() > 0)
						phone = phone + NEWLINE;
					phone = phone + phoneValue;
				}
				else if (nodeName.equals(TAGNAME_EMAILADDRESS))
				{
					String emailValue = getElementValue(childNode);
					if (email.length() > 0)
						email = email + NEWLINE;
					email = email + emailValue;
				}
			}
			childNode = childNode.getNextSibling();
		}

		ABA_OOD_contactData data = new ABA_OOD_contactData(name, phone, email);
		return data;
	}

	//pre:  DOM data structure exists.
	//post: Returns set of all contact names in the address book, in alphabetical order.
	public Collection<ABA_OOD_modelContact> getContactList()
	{
		ABA_OOD_modelContactList contactList = new ABA_OOD_modelContactList();
		//Get list of <id> and <name> nodes.
		NodeList idNodes = dom.getElementsByTagName(TAGNAME_ID);
		NodeList nameNodes = dom.getElementsByTagName(TAGNAME_NAME);
		if (idNodes.getLength() != nameNodes.getLength())
			System.out.println("ERROR! number of id values does NOT match number of name values.");
		else
			//Iterate through the list of <id> and <name> nodes, adding each contact to our list.
			for (int idx = 0; idx < idNodes.getLength(); idx++)
			{
				String idValue = getElementValue(idNodes.item(idx));
				String nameValue = getElementValue(nameNodes.item(idx));
				ABA_OOD_modelContact contact = new ABA_OOD_modelContact(idValue, nameValue);
				contactList.addContact(contact);
			}
		return contactList.getContacts();
	}

	//pre:  DOM has been updated.
	//post: Save DOM to a new XML file name.
	public void saveDOMtoXML()
	{
		try
		{
//			String outputFileName = xmlFileName.substring(0,xmlFileName.length()-4) +
//								"_OUTPUT" + xmlFileName.substring(xmlFileName.length()-4);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			DOMSource source = new DOMSource(dom);
			StreamResult result = new StreamResult(new File(XML_FILE_NAME));
			transformer.transform(source, result);
			System.out.println("Updated DOM written to " + XML_FILE_NAME);
		}
		catch (TransformerFactoryConfigurationError ex)
		{
			System.out.println(ex);
		}
		catch (TransformerConfigurationException ex)
		{
			System.out.println(ex);
		}
		catch (TransformerException ex)
		{
			System.out.println(ex);
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
	}

	//pre: parent is an Element node.
	//post: created new element with a child Text node; new element is child of parent.
	private void addChildAndDataNodes(Node parent, String tagName, String tagData)
	{
		Element newNode = dom.createElement(tagName);
		addChildElement(parent, newNode);
		//Create text node to store the new data value; make this a child of newNode.
		Text newText = dom.createTextNode(tagData);
		addChildElement(newNode, newText);
	}

	//pre: parent and child are Element nodes.
	//post: child is now a child element of parent.
	private void addChildElement(Node parent, Node child)
	{
		parent.appendChild(child);
	}

	//pre:  Have a file name for an XML file.
	//post: Created an XML DOM object for filename.
	//		  Any exceptions causes the XML DOM to be null.
	private Document createDOM(String filename)
	{
		Document dom;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try
		{
			DocumentBuilder db = dbf.newDocumentBuilder();
			dom = db.parse(filename);
		}
		catch (ParserConfigurationException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (IOException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (SAXException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (Exception ex)
		{
			System.out.println(ex);
			dom = null;
		}
		return dom;
	}

	//pre: dataValues contains zero or more values separated by NEWLINE characters.
	//post: Saves each non-empty string value in the DOM.
	private void extractAndSaveDataValues(Node parent, String tagName, String dataValues)
	{
		String[] dataList = dataValues.split(NEWLINE);
		for (int idx =0; idx < dataList.length; idx++)
		{
			if (dataList[idx].length() > 0)
				addChildAndDataNodes(parent, tagName, dataList[idx]);
		}
	}

	//pre: id value exists in DOM.
	//post: returns the contact node that contains id value.
	private Node getContactNode(String id)
	{
		Node contactNode;
		//Get list of <id> nodels
		NodeList idNodes = dom.getElementsByTagName(TAGNAME_ID);
		//Iterate through the list of <id> nodes, looking for the id value.
		int idx = 0;
		String idNodeValue = getElementValue(idNodes.item(idx));
		while (! idNodeValue.equals(id))
		{
			idx++;
			if (idx < idNodes.getLength())
				idNodeValue = getElementValue(idNodes.item(idx));
			else
			{
				System.out.println("ERROR! Did not find id value " + id + " in the DOM.");
				break;
			}
		}
		if (idx < idNodes.getLength())
			contactNode = idNodes.item(idx).getParentNode();
		else
			contactNode = null;
		return contactNode;
	}

	//pre: aNode is an Element in the DOM.
	//post: returns a string value that contains the data for aNode.
	private String getElementValue(Node aNode)
	{
		boolean valueNotFound = true;
		String nodeValue = EMPTY_STRING;
		//Iterate through all child nodes of aNode, until we find a data value.
		Node childNode = aNode.getFirstChild();
		while (childNode != null && valueNotFound)
		{
			if (childNode.getNodeType() == Node.TEXT_NODE)
			{
				nodeValue = childNode.getNodeValue();
				if (nodeValue.length() > 0)
					//Found a text node that contains data
					valueNotFound = false;
			}
			childNode = childNode.getNextSibling();
		}
		return nodeValue;
	}

	//pre: 
	//post: 
	private void saveMaxIdValue()
	{
		BigInteger id;
		String idStr;
		Node nextIdNode;
		//Get list of <id> nodels
		NodeList idNodes = dom.getElementsByTagName(TAGNAME_ID);
		//Initialize maxId
		maxId = new BigInteger("0");
		//Iterate through the list of <id> nodes, updating maxId when applicable
		for (int idx = 0; idx < idNodes.getLength(); idx++)
		{
			nextIdNode = idNodes.item(idx);
			if (nextIdNode != null)
			{
				idStr = getElementValue(nextIdNode);
				try
				{
					id = new BigInteger(idStr);
					//Update the maxId valud, if appropriate.
					maxId = maxId.max(id);
					System.out.println("saveMaxIdValue idStr=" + idStr + " maxId=" + maxId);
				}
				catch (Exception ex)
				{
				}
			}
		} //for
	}
}
