//ABA_OOD_modelContactList.java: very simple object-oriented design example.
//   This class implements a container for contact data.

import java.util.Collection;
import java.util.TreeMap;

public class ABA_OOD_modelContactList
{
	private TreeMap<String, ABA_OOD_modelContact> contacts;

	public ABA_OOD_modelContactList()
	{
		contacts = new TreeMap<String, ABA_OOD_modelContact>();
	}

	//pre: 
	//post: 
	public void addContact(ABA_OOD_modelContact contact)
	{
		contacts.put(contact.getName(), contact);
	}

	//pre: 
	//post: 
	public Collection<ABA_OOD_modelContact> getContacts()
	{
		return contacts.values();
	}

}
