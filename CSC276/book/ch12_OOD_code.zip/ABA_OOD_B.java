//ABA_OOD_B.java: very simple object-oriented design example.
//   Meets same requirements as Chapter 10 except the design uses MVC. 

public class ABA_OOD_B
{
	public static void main(String[] args)
	{
		ABA_OOD_B_controller aba = new ABA_OOD_B_controller();
		aba.go();
	}
}
