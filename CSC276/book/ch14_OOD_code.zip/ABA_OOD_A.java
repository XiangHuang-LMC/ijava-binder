//ABA_OOD_A.java: very simple object-oriented design example.
//   Meets same requirements as Chapter 10 except the design uses MVC. 

public class ABA_OOD_A
{
	public static void main(String[] args)
	{
		ABA_OOD_A_controller aba = new ABA_OOD_A_controller();
		aba.go();
	}
}
