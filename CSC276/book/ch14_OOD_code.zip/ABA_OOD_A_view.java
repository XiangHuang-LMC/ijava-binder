//ABA_OOD_A_view.java: very simple object-oriented design example.
//   Meets same requirements as Chapter 10 except the design uses MVC. 
//   This class implements the view component.

import java.util.NoSuchElementException;
import java.util.Scanner;

public class ABA_OOD_A_view
{
	private ABA_OOD_A_viewDisplayData display;
	private ABA_OOD_A_viewObtainData obtain;

	private final String CREATE = "C";
	private final String DISPLAY = "D";
	private final String EXIT = "X";

	public ABA_OOD_A_view()
	{
		this.display = new ABA_OOD_A_viewDisplayData();
		this.obtain = new ABA_OOD_A_viewObtainData();
	}

	//pre: Get a request from the user.
	//post: Returns the request entered by the user.
	public ABA_OOD_A_viewRequest getViewRequest()
	{
		ABA_OOD_A_viewRequest request;
	
		String menuChoice = getValidMenuChoice();
		if (menuChoice.equals(CREATE))
		{
			ABA_OOD_contactData data = getContactData();
			request = new ABA_OOD_A_viewRequest(ABA_OOD_A_viewRequest.REQUEST.CREATE, data);
		}
		else if (menuChoice.equals(DISPLAY))
		{
			ABA_OOD_contactData data = getContactName();
			request = new ABA_OOD_A_viewRequest(ABA_OOD_A_viewRequest.REQUEST.DISPLAY, data);
		}
		else //menuChoice.equals(EXIT)
			request = null;

		return request;
	}

	//pre: 
	//post: 
	public void displayContactData(ABA_OOD_contactData data)
	{
		display.msgLine("");
		display.msg("Contact: ");
		if (data == null)
			display.msgLine("Does not exist.");
		else
			display.msgLine(data.toString());
	}

	//pre: The most recent contact name entered by user is not valid.
	//post: An appropriate error message is displayed.
	public void displayInvalidName(String invalidName)
	{
		display.msgLine("The contact name you entered '" + invalidName + "' is not valid." +
				" A contact name must contain at least one letter AND" +
				" must contain only uppercase and lowercase letters and spaces.");
	}

	//pre: The most recent phone number entered by user is not valid.
	//post: An appropriate error message is displayed.
	public void displayInvalidPhone(String invalidPhone)
	{
		display.msgLine("The phone number you entered '" + invalidPhone + "' is not valid." +
				" A phone number must contain one or more digits.");
	}

	//pre: Display a message to the user.
	//post: Message has been displayed.
	public void displayRegExError(String msg)
	{
		display.msgLine("\nLogic error using a regular expression to validate a " + msg + ".\n");
	}

	//pre: Need to display menu of options to user.
	//post: Menu of options has been displayed.
	private void displayMenu()
	{
		display.msgLine("");
		display.msgLine(CREATE + "\tCreate address book entry");
		display.msgLine(DISPLAY + "\tDisplay address book entry");
		display.msgLine(EXIT + "\tExit");
		display.msg("Choice (" + CREATE + ", " + DISPLAY + ", " + EXIT + "): ");
	}

	//pre: Obtains from user all of the contact data for a single person.
	//post: Returns object containing all of the user data entered.
	private ABA_OOD_contactData getContactData()
	{
		ABA_OOD_contactData userData;
		String name, phone, email;
		
		name = obtain.textLine("Enter contact name: ");
		phone = obtain.textLine("Enter phone number for " + name + ": ");
		email = obtain.textLine("Enter email address for " + name + ": ");
		userData = new ABA_OOD_contactData(name, phone, email);

		return userData;
	}

	//pre: Obtains from user a contact name for a single person.
	//post: Returns object containing the user data entered.
	private ABA_OOD_contactData getContactName()
	{
		ABA_OOD_contactData userData;
		String name;
		
		name = obtain.textLine("Enter contact name: ");
		userData = new ABA_OOD_contactData(name, null, null);

		return userData;
	}

	//pre: Need to display menu and obtain a menu choice.
	//post: Returns a valid menu choice entered by user.
	private String getValidMenuChoice()
	{
		String menuChoice = null;
		displayMenu();
		menuChoice = obtain.textLine("").toUpperCase();
		while (invalidMenuChoice(menuChoice))
		{
			display.msgLine("Error: must enter " + CREATE + ", " + DISPLAY + ", or " + EXIT + " as your menu choice.\n");
			displayMenu();
			menuChoice = obtain.textLine("").toUpperCase();
		}
		return menuChoice;
	}

	//pre: Determine if menuChoice entered is invalid.
	//post: Returns true when menuChoice is not valid.
	private boolean invalidMenuChoice(String menuChoice)
	{
		boolean invalid = true;
		if (menuChoice.equals(CREATE) || menuChoice.equals(DISPLAY) || menuChoice.equals(EXIT))
			invalid = false;
		return invalid;
	}
}
