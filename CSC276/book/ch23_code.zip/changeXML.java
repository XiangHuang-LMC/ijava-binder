import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;
import org.xml.sax.*;

public class changeXML
{
	Document dom;
	String xmlFileName;

	public static void main(String[] args)
	{
		changeXML change = new changeXML();
		change.go();
	}

	//pre:  Need to create an XML DOM object.
	//post: An XML DOM object has been created.
	public changeXML()
	{
		xmlFileName = getFileName();
		dom = createDOM(xmlFileName);
	}

	//pre:  Want to display the contents of and XML DOM.
	//post: The contents of an XML DOM has been displayed.
	public void go()
	{
		if (dom == null)
			System.out.println("Error createing XML DOM. Program terminating.");
		else
			changeDOM();
	}

	//pre:  Need to get a file name from the user.
	//post: Returns file name entered by user.
	private String getFileName()
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a file name (with extension): ");
		String filename = scan.nextLine();
		return filename.trim();
	}

	//pre:  Have a file name for an XML file.
	//post: Created an XML DOM object for filename.
	//		  Any exceptions causes the XML DOM to be null.
	private Document createDOM(String filename)
	{
		Document dom;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try
		{
			DocumentBuilder db = dbf.newDocumentBuilder();
			dom = db.parse(filename);
		}
		catch (ParserConfigurationException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (IOException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (SAXException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (Exception ex)
		{
			System.out.println(ex);
			dom = null;
		}
		return dom;
	}

	//pre:  Want to add one author to the first book instance.
	//post: One author Element and associated Text data value added to first book instance.
	//		  A new XML file has been written.
	private void changeDOM()
	{
		String authorName = getAuthorName();
		addAuthorToFirstBook(authorName);
		saveDOMtoXML();
	}

	//pre: User ready to enter their name.
	//post: Returns a name.
	private String getAuthorName()
	{
		String authorName;
		Scanner scan;
		scan = new Scanner(System.in);
		do
		{
			System.out.print("Enter your name: ");
			authorName = scan.nextLine();
			authorName = authorName.trim();
		} while (authorName.equals(""));
		return authorName;
	}

	//pre: need to add authorName as an author for the first book instance.
	//post: new author added to first book instance.
	private void addAuthorToFirstBook(String authorName)
	{
		//Get location of the first book node.
		NodeList nodes = dom.getElementsByTagName("book");
		if (nodes != null && nodes.getLength() > 0)
		{
			//The XML file has at least one book instance.
			Element firstBookNode = (Element)nodes.item(0);
			//Create text node to store the new author name.
			Text newText = dom.createTextNode(authorName);
			//Create element node for the new author.
			Element newElement = dom.createElement("author");
			//Add text node as child of the author element
			newElement.appendChild(newText);
			//Add author element to first book instance
			firstBookNode.appendChild(newElement);
		}
	}

	//pre:  DOM has been updated.
	//post: Save DOM to a new XML file name.
	private void saveDOMtoXML()
	{
		try
		{
			String outputFileName = xmlFileName.substring(0,xmlFileName.length()-4) +
								"_OUTPUT" + xmlFileName.substring(xmlFileName.length()-4);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			DOMSource source = new DOMSource(dom);
			StreamResult result = new StreamResult(new File(outputFileName));
			transformer.transform(source, result);
			System.out.println("Updated DOM written to " + outputFileName);
		}
		catch (TransformerFactoryConfigurationError ex)
		{
			System.out.println(ex);
		}
		catch (TransformerConfigurationException ex)
		{
			System.out.println(ex);
		}
		catch (TransformerException ex)
		{
			System.out.println(ex);
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
	}
}
