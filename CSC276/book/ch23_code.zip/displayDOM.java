import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;

public class displayDOM
{
	Document dom;

	public static void main(String[] args)
	{
		displayDOM display = new displayDOM();
		display.go();
	}

	//pre:  Need to create an XML DOM object.
	//post: An XML DOM object has been created.
	public displayDOM()
	{
		String xmlFileName = getFileName();
		dom = createDOM(xmlFileName);
	}

	//pre:  Want to display the contents of and XML DOM.
	//post: The contents of an XML DOM has been displayed.
	public void go()
	{
		if (dom == null)
			System.out.println("Previous error preventing XML from being displayed.");
		else
			displayDOM(dom);
	}

	//pre:  Need to get a file name from the user.
	//post: Returns file name entered by user.
	private String getFileName()
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a file name (with extension): ");
		String filename = scan.next();
		return filename;
	}

	//pre:  Have a file name for an XML file.
	//post: Created an XML DOM object for filename.
	//		  Any exceptions causes the XML DOM to be null.
	private Document createDOM(String filename)
	{
		Document dom;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try
		{
			DocumentBuilder db = dbf.newDocumentBuilder();
			dom = db.parse(filename);
		}
		catch (ParserConfigurationException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (IOException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (SAXException ex)
		{
			System.out.println(ex);
			dom = null;
		}
		catch (Exception ex)
		{
			System.out.println(ex);
			dom = null;
		}
		return dom;
	}

	//pre:  Want to display the contents of an XML DOM.
	//post: An entire XML DOM has been displayed.
	private void displayDOM(Document dom)
	{
		System.out.println("XML DOM node structure.\n" +
				"Each indentiation is another level in the tree.\n" +
				"Displaying values for node type, name and value inside [].");
		Element docElement = dom.getDocumentElement();
		displayDOMhelper(docElement, 0);
	}

	//pre:  Want to display one node in an XML DOM.
	//post: Displayed a node (element) and all of its child and sibling nodes.
	//		  This is a recursive method.
	private void displayDOMhelper(Node element, int indentLevel)
	{
		//display information for this element
		displayElement(element, indentLevel);

		//display information for each child of this element
		if (element.hasChildNodes())
			displayDOMhelper(element.getFirstChild(), indentLevel + 1);
			
		//display information for each sibling of this element
		Node nextSibling = element.getNextSibling();
		if (nextSibling != null)
			displayDOMhelper(nextSibling, indentLevel);
	}

	//pre:  Want to display information about one XML DOM Node object.
	//post: Dislayed informaiton for one XML DOM Node object.
	private void displayElement(Node element, int indentLevel)
	{
		final String TWO_SPACES = "  ";
		for (int indent = 0; indent < indentLevel; indent++)
			System.out.print(TWO_SPACES);

		System.out.println("type[" + getNodeType(element) +
				"],name[" + element.getNodeName() +
				"],value[" + getNodeValue(element) + "]");
	}

	//pre:  Need to obtain the type for a XML DOM Node.
	//post: Return the type for a XML DOM Node.
	private String getNodeType(Node element)
	{
		String nodeType;
		switch (element.getNodeType())
		{
			case Node.ATTRIBUTE_NODE:
				nodeType = "Attribute";
				break;
			case Node.CDATA_SECTION_NODE:
				nodeType = "CdataSection";
				break;
			case Node.COMMENT_NODE:
				nodeType = "Comment";
				break;
			case Node.DOCUMENT_FRAGMENT_NODE:
				nodeType = "DocumentFragment";
				break;
			case Node.DOCUMENT_NODE:
				nodeType = "Document";
				break;
			case Node.DOCUMENT_TYPE_NODE:
				nodeType = "DocumentType";
				break;
			case Node.ELEMENT_NODE:
				nodeType = "Element";
				break;
			case Node.ENTITY_NODE:
				nodeType = "Entity";
				break;
			case Node.ENTITY_REFERENCE_NODE:
				nodeType = "EntityReference";
				break;
			case Node.NOTATION_NODE:
				nodeType = "Notation";
				break;
			case Node.PROCESSING_INSTRUCTION_NODE:
				nodeType = "ProcessingInstruction";
				break;
			case Node.TEXT_NODE:
				nodeType = "Text";
				break;
			default:
				nodeType = "Unknown";
				break;
		}
		return nodeType;
	}

	//pre:  Need to obtain the value of a XML DOM Node.
	//post: Return the value of XML DOM Node, after removing leading and trailing whitespace.
	private String getNodeValue(Node element)
	{
		String nodeValue = element.getNodeValue();
		if (nodeValue == null)
			nodeValue = "";
		else
			nodeValue = nodeValue.trim();
		return nodeValue;
	}
}
