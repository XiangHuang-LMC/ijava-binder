import java.util.Scanner;

public class BMI_01_Main_NoValidation
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter your weight in pounds: ");
		double weight = scan.nextDouble();
		
		System.out.print("Enter your height in inches: ");
		double height = scan.nextDouble();
		  
		double bmi = weight / Math.pow(height,2.0) * 703;

		String result = null;
		if (bmi <= 18.5)
			result = "underweight";
		else if (bmi <= 25)
			result = "normal";
		else if (bmi <= 30)
			result = "overweight";
		else
			result = "obese";

		System.out.println("Your BMI category is " + result);
	}
}
