public class BMI_05_Main_NoValidation
{
	public static void main(String[] args)
	{
		BMI_05_GUISwing_NoValidation bmi_gui = new BMI_05_GUISwing_NoValidation();
	}
}
